<?php

	require_once '../include/db.php';

	/*
				Product Image: <input type='file' class='form-control' id='newimage' name='imgfile'><br>

					*/
?>


<?php

	
	

	if(isset($_POST['caddtotable']))
	{
		echo "<div>
			
		</div>";
	}	



?>